package Entidad;

public class Cita {
    private int IDcita;
    private int IDdoctor;
    private int IDpaciente;
    private int IDhorario;
    private String Fecha;
    private String Diagnostico;
    private String Tratamiento;
    private String Observaciones;

    public int getIDcita() {
        return IDcita;
    }

    public void setIDcita(int IDcita) {
        this.IDcita = IDcita;
    }

    public int getIDdoctor() {
        return IDdoctor;
    }

    public void setIDdoctor(int IDdoctor) {
        this.IDdoctor = IDdoctor;
    }

    public int getIDpaciente() {
        return IDpaciente;
    }

    public void setIDpaciente(int IDpaciente) {
        this.IDpaciente = IDpaciente;
    }

    public int getIDhorario() {
        return IDhorario;
    }

    public void setIDhorario(int IDhorario) {
        this.IDhorario = IDhorario;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public String getDiagnostico() {
        return Diagnostico;
    }

    public void setDiagnostico(String Diagnostico) {
        this.Diagnostico = Diagnostico;
    }

    public String getTratamiento() {
        return Tratamiento;
    }

    public void setTratamiento(String Tratamiento) {
        this.Tratamiento = Tratamiento;
    }

    public String getObservaciones() {
        return Observaciones;
    }

    public void setObservaciones(String Observaciones) {
        this.Observaciones = Observaciones;
    }
    
    

}
