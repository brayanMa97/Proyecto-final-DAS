/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidad;

/**
 *
 * @author PC
 */
public class Registro {
    
    private char id;
    private char user_name;
    private char clave;
    private char correo_id;
    private int telefono;

    public char getId() {
        return id;
    }

    public void setId(char id) {
        this.id = id;
    }

    public char getUser_name() {
        return user_name;
    }

    public void setUser_name(char user_name) {
        this.user_name = user_name;
    }

    public char getClave() {
        return clave;
    }

    public void setClave(char clave) {
        this.clave = clave;
    }

    public char getCorreo_id() {
        return correo_id;
    }

    public void setCorreo_id(char correo_id) {
        this.correo_id = correo_id;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    
    
    
}
