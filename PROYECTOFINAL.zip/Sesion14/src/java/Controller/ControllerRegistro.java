/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Config.Conexion;
import Entidad.*;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ControllerRegistro {
    Conexion con = new Conexion();
    JdbcTemplate jdbctemplate = new JdbcTemplate(con.Conectar());
    ModelAndView mav = new ModelAndView();
   

    @RequestMapping("listar.htm")
    public ModelAndView Listar(){
        String sql = "Select * from tbregistro";
        List datos=jdbctemplate.queryForList(sql);
        mav.addObject("lista",datos);
        mav.setViewName("listar");
        return mav;
    }
    
    @RequestMapping(value="/Registro/agregar.htm", method = RequestMethod.GET )
    public ModelAndView Agregar(){
        mav.addObject(new Registro());
        mav.setViewName("/Registro/agregar");
        return mav;
    }
    
    @RequestMapping(value="/Registro/agregar.htm", method = RequestMethod.POST )
    public ModelAndView Agregar(Registro objEsp){
        String sql = "insert into tbregistro values(?,?,?,?,?)";
        this.jdbctemplate.update(sql,objEsp.getId(), objEsp.getUser_name(), objEsp.getClave(), objEsp.getCorreo_id(),
                objEsp.getTelefono());        
        return new ModelAndView("redirect:listar.htm");
    }
    
    @RequestMapping(value="/Registro/editar.htm", method = RequestMethod.GET )
    public ModelAndView Editar(HttpServletRequest request){
        int id = Integer.parseInt(request.getParameter("ID"));
        String sql = "Select * from tbregistro where Id = ?";
        List datos=jdbctemplate.queryForList(sql,id);
        mav.addObject("lista",datos);
        mav.setViewName("/Registro/editar");
        return mav;
    }
    
    @RequestMapping(value="/Registro/editar.htm", method = RequestMethod.POST )
    public ModelAndView Editar(Registro objEsp){
        String sql = "update tbregistro set user_name=?,clave=?,correo_id=?,telefono=? where id=?";
        this.jdbctemplate.update(sql,objEsp.getUser_name(), objEsp.getClave(),objEsp.getCorreo_id(), objEsp.getTelefono(), objEsp.getId());        
        return new ModelAndView("redirect:listar.htm");
    }
    
    @RequestMapping(value="/Registro/eliminar.htm", method = RequestMethod.GET )
    public ModelAndView Eliminar(HttpServletRequest request){
        int id = Integer.parseInt(request.getParameter("id"));
        String sql = "Select * from tbregistro where id = ?";
        List datos=jdbctemplate.queryForList(sql,id);
        mav.addObject("lista",datos);
        mav.setViewName("/Registro/eliminar");
        return mav;
    }
    
    @RequestMapping(value="eliminar.htm", method = RequestMethod.POST )
    public ModelAndView Eliminar(Registro objEsp){
        String sql = "delete from tbregistro where ID=?";
        this.jdbctemplate.update(sql, objEsp.getId());        
        return new ModelAndView("listar.htm");
    }
    
    public List ListarRegistro(){
        String sql = "Select * from tbregistro";
        List datos=jdbctemplate.queryForList(sql);
        return datos;
    }


    }

        
    
            

